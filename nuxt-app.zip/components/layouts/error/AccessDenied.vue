<script lang="ts" setup>

</script>

<template>
  <div class="layout-empty">
    <slot />
  </div>
</template>