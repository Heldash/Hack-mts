<template>
  <NuxtLayout>
    <!--NuxtLoadingIndicator /-->
    <NuxtPage />
  </NuxtLayout>
</template>
