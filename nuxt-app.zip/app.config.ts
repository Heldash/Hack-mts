export default defineAppConfig({
  title: 'Sakai Nuxt',
  description: '',
  baseURL: '/'
});
