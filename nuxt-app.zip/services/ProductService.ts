export default class ProductService {
  getProductsSmall() {
    return null //fetch('/data/products-small.json').then(res => res.json()).then(d => d.data);
  }

  getProducts() {
    return null //fetch('/data/products.json').then(res => res.json()).then(d => d.data);
  }

  getProductsWithOrdersSmall() {
    return null //fetch('/data/products-orders-small.json').then(res => res.json()).then(d => d.data);
  }
}
